#include <stdio.h>
#include <string.h>

int main(){
    char palavra[11];

    printf("Digite a palavra: \n");
    scanf("%s", palavra);

    printf("A palavra digitada foi: %s ", palavra);

    return 0;
    
}